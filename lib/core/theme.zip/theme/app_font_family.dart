class AppFontFamily {
  AppFontFamily._();
  static const String manrope = "Manrope";
}
