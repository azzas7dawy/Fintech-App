// lib/features/home/data/datasources/repos/home_repo.dart
import 'package:dio/dio.dart';
import 'package:fintech_app/core/di/dependency_injection.dart';
import 'package:fintech_app/features/home/data/home_servicea/api_client_service.dart';
import 'package:fintech_app/features/home/data/models/top_gainers_response.dart';
import 'package:fintech_app/features/home/data/models/trending_response.dart';

class HomeAggregate {
  final List<TrendingCoin> trending;
  final List<GainerItem> gainers;

  HomeAggregate({this.trending = const [], this.gainers = const []});
}

class HomeRepository {
  final ApiClient api;
  HomeRepository(this.api);

  Future<List<TrendingCoin>> getTrendingCoins(
    String apiKey,
  ) async {
    try {
      final resp = await api.getTrending( apiKey);
      return resp.coins;
    } on DioError catch (e) {
      final serverMessage = _extractServerMessage(e);
      throw Exception(serverMessage ?? 'Failed to load trending: ${e.message}');
    } catch (e) {
      throw Exception('Failed to load trending: $e');
    }
  }

  Future<List<GainerItem>> getTopGainers({
    String vsCurrency = 'usd',
    String? duration,
    int? topCoins,
  }) async {
    try {
      final resp = await api.getTopGainers(vsCurrency: vsCurrency, duration: duration, topCoins: topCoins);
      return resp.topGainers;
    } on DioError catch (e) {
      final serverMessage = _extractServerMessage(e);
      throw Exception(serverMessage ?? 'Failed to load gainers: ${e.message}');
    } catch (e) {
      throw Exception('Failed to load gainers: $e');
    }
  }

  /// aggregate fetch -> يجلب الاثنين ويرجع HomeAggregate
  Future<HomeAggregate> fetchHome({String vsCurrency = 'usd'}) async {
    try {
      final results = await Future.wait([
        api.getTrending( 'CG-wcMwgtCgr4YU5ff8atbsD67W'), // TrendingResponse
        api.getTopGainers(vsCurrency: vsCurrency), // TopGainersResponse
      ]);

      final trendingResp = results[0] as TrendingResponse;
      final gainersResp = results[1] as TopGainersResponse;
        dio.options.headers['CG-wcMwgtCgr4YU5ff8atbsD67W'] = 'CG-wcMwgtCgr4YU5ff8atbsD67W';

      return HomeAggregate(trending: trendingResp.coins, gainers: gainersResp.topGainers);
    } on DioError catch (e) {
  print('--- DioError ---');
  print('Request URL: ${e.requestOptions.uri}');
  print('Method: ${e.requestOptions.method}');
  print('Query: ${e.requestOptions.queryParameters}');
  print('Headers: ${e.requestOptions.headers}');
  print('Response status: ${e.response?.statusCode}');
  print('Response data: ${e.response?.data}');
  final serverMessage = _extractServerMessage(e);
  throw Exception(serverMessage ?? 'Failed: ${e.message}');
}
  }

  String? _extractServerMessage(DioError e) {
    try {
      final data = e.response?.data;
      if (data is Map && data.containsKey('error_message')) {
        return data['error_message']?.toString();
      }
      if (data is Map && data.containsKey('message')) {
        return data['message']?.toString();
      }
    } catch (_) {}
    return null;
  }
}
