// lib/api/api_client.dart
import 'package:dio/dio.dart';
import 'package:fintech_app/features/home/data/models/top_gainers_response.dart';
import 'package:fintech_app/features/home/data/models/trending_response.dart';
import 'package:retrofit/retrofit.dart';

part 'api_client_service.g.dart';

@RestApi(baseUrl: 'https://api.coingecko.com/api/v3')
abstract class ApiClient {
  factory ApiClient(Dio dio) = _ApiClient;

  @GET('/search/trending')
  Future<TrendingResponse> getTrending(
    @Query('api_key')String api_key,
  );
  //

  @GET('/coins/top_gainers_losers')
  Future<TopGainersResponse> getTopGainers({
    @Query('vs_currency') String vsCurrency = 'usd',
    @Query('duration') String? duration, // e.g. '24h'
    @Query('top_coins') int? topCoins,
  });
}
Dio createDio({required String apiKey, required String baseUrl}) {
  final dio = Dio(BaseOptions(
    baseUrl: 'https://api.coingecko.com/api/v3', // FREE/DEMO
    connectTimeout: const Duration(seconds: 10),
    receiveTimeout: const Duration(seconds: 10),
  ));

  // Demo key
  dio.options.headers["x-cg-api-key CG-wcMwgtCgr4YU5ff8atbsD67W5"] = 'CG-wcMwgtCgr4YU5ff8atbsD67W5';

  dio.interceptors.add(LogInterceptor(
    request: true,
    requestHeader: true,
    responseBody: true,
    error: true,
  ));

  return dio;
}
